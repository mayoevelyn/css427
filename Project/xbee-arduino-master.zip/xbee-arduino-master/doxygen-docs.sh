#!/bin/bash
doxygen Doxyfile
